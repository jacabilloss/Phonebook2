package com.addressbook.android.util

/**
 * Created by Administrator on 3/15/18.
 */
object Constant {
    val AB_SPLASH_TIME: Long = 1500




    val MM_secrets = "secrets"
    val AB_USER_MAP = "USER_MAP"

    val Key_editAddressBook = "editAddressBook"


}